/**

 * File Name : Api_Gpio.c

 *

 * Copyright 2020 by OnPoom Co,.Ltd

 *

 * Dept : R&D Center, F/W

 *

 * Developer : Se-Yeon. Jo (333, jsy95@onpoom.co.kr)

 *

 * Classify : API

 *

 * Version : 0.01

 *

 * Created Date : 2020-03-09

 *

 * File Description : Iwt 소스 기반 Gpio 제어 API

 *

 * Debugging List

 * 2020-03-09 : 1st Release

 */

extern "C"{
#include <semaphore.h>

#include <sys/stat.h>

#include <sys/types.h>

#include <fcntl.h>

#include <stdio.h>

#include <stdlib.h>

#include <unistd.h>

#include <string.h>

#ifdef Q_WS_QWS
#include <sys/ioctl.h>
#endif

#include "Api_Gpio.h"

#include "Api_Defines.h"
}

// ----------------------------------------------------------------------------------------------------- //

// Debugging Option...																					 //

// ----------------------------------------------------------------------------------------------------- //

#define xxx_DEBUG


#ifdef xxx_DEBUG

#define dp(fmt, args...) printf(fmt,## args)

#define dlp(fmt,args...) printf("[%s,%s(),%d]"fmt,__FILE__,__FUNCTION__,__LINE__,## args)

#else

#define dp(fmt, args...)

#define dlp(fmt,args...)

#endif

// ----------------------------------------------------------------------------------------------------- //


static int GpioFd=-1;


static int fdGpio=-1;


//static sem_t semGpio;

//static sem_t writeGpio;

//static sem_t readGpio;


static int OpenGpio(char *dev)

{

	int fd;

	fd = open(dev, O_RDWR);

	if (fd < 0)

	{

		dlp("[Err] OpenGpio\r\n");

		exit(0);

	}

	printf("Gpio Driver Open OK\r\n");

	return fd;

}


// ----------------------------------------------------------------------------------------------------- //

// Debugging Option...																					 //

// ----------------------------------------------------------------------------------------------------- //

#define xxx_DEBUG


#ifdef xxx_DEBUG

#define dp(fmt, args...) printf(fmt,## args)

#define dlp(fmt,args...) printf("[%s,%s(),%d]"fmt,__FILE__,__FUNCTION__,__LINE__,## args)

#else

#define dp(fmt, args...)

#define dlp(fmt,args...)

#endif

// ----------------------------------------------------------------------------------------------------- //


//======================================================================================

#if 0

/** 

 * @date 2020.02

 * @brief 

 	gpio 핀 활성 함수

 * @param fd 

 	GPIO 드라이버 FD 값 입력

 * @param gpio

 	설정할 GPIO 핀 번호

 * @param flags

	설정 Flag

	INPUT, OUTPUT, ACT_LOW, OPEN_DRAIN, OPEN_SOURCE

 * @param defult_val

	gpio 출력 설정 시 초기 설정 값

	LOW, HIGH, 0, 1

 * @return 

 	성공: 설정한 gpio fd, 실패 -1

 */

static int GpioEnable(gpio_t *gpio)

{

    class gpiohandle_request req;

	int ret;


	req.flags = gpio->flags;

	req.lines = 1;

	req.lineoffsets[0] = gpio->gpio;

	req.default_values[0] = gpio->defult_val;


	ret = ioctl(gpio->fd, GPIO_GET_LINEHANDLE_IOCTL, &req);

	if (ret < 0)

   	{

		printf("GPIO_GET_LINEHANDLE_IOCTL failed.\n");

		return -1;

	}

	return req.fd;

}


static int GpioRead(int req_fd, int *value)

{

    class gpiohandle_data data;

	int ret;


	memset(&data, 0, sizeof(data));


    ret = ioctl(req_fd, GPIOHANDLE_GET_LINE_VALUES_IOCTL, &data);

	if (ret < 0) 

	{

		printf("GPIO_GET_LINE_VALUES_IOCTL failed.\n");

		return -1;

	}

	//printf("line %d is %s\n", gpio, data.values[0] ? "high" : "low");


	*value = data.values[0];

	return 0;

}


static int GpioWrite(int req_fd, unsigned char value)

{

    class gpiohandle_data data;

	int ret;


	memset(&data, 0, sizeof(data));

	data.values[0] = value;


	ret = ioctl(req_fd, GPIOHANDLE_SET_LINE_VALUES_IOCTL, &data);

	if (ret < 0)

   	{

		printf("GPIO_SET_LINE_VALUES_IOCTL failed.\n");

		return -1;

	}

	return 0;

}


#endif

//==================================================================================


#ifdef Q_WS_QWS
int SetDirectionPortPin(unsigned char port, unsigned char pin, unsigned char direct)

{

    andGpioCtrlData_t control;

	int ret = 0;

	

	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );

	control.gpioPort = port;

	control.gpioPin = pin;


	//sem_wait(&semGpio);


	if( (ret = ioctl(GpioFd, GPIO_FREE, &control)) < 0 )

	{

		printf("[Err] GPIO free fail\r\n");

		perror("gio free() : ");

	}

	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );

	control.gpioPort = port;

	control.gpioPin = pin;

	control.data = direct;


	if( (ret = ioctl(GpioFd, GPIO_DIR_SET, &control)) < 0 )

	{

		printf("[Err] Gpio Direction Init Fail Port[%d]|Pin[%d]-",port,pin);

		perror("Message");

		return -1;

	}

	//sem_post(&semGpio);

	return 1;

}


int WriteGpio(unsigned int port, unsigned int pin, unsigned char data)

{
	printf("Now we are writing GPIO\n");
	int ret = 0;

	andGpioCtrlData_t control;

	printf("Port = %d\n PIN = %d\n Data = %d\n", port, pin, data);

	switch( data )

	{

		case GPIO_LOW : printf("GPIO_LOW\n");

		case GPIO_HIGH : printf("GPIO_HIGH\n");

			break;

		default :

			return -1;

	}


	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );

	control.gpioPort = port;

	control.gpioPin = pin;

	control.data = data;

	printf("good\n");

	//sem_wait(&writeGpio);

	if( (ret = ioctl(GpioFd, GPIO_OUTPUT_WRITE, &control)) < 0 )

	{

		printf("[Err] GPIO Port:%d, Pin:%d, Data:%d \n\r", port ,pin, data);

		return -1;

	}


	dlp("[Test] WriteGpio Port:%d, Pin:%d Data:%d\r\n",port, pin, data );	

	//sem_post(&writeGpio);

	return 1;

}


char ReadGpio(unsigned int port, unsigned int pin)

{

	char ret = 0;

	andGpioCtrlData_t control;


	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );


	control.gpioPort = port;

	control.gpioPin = pin;


	//sem_wait(&readGpio);


	if( (ret = ioctl(GpioFd, GPIO_INPUT_READ, &control)) < 0 )

	{

		dlp("[Err] ReadGpio Port:%d, Pin:%d\r\n",port, pin );	

		return -1;

	}


	//sem_post(&readGpio);


	ret = (control.data & 0x01);


	//dlp("[Test] ReadGpio Port:%d, Pin:%d Data%d\r\n",port, pin, ret);	

	return ret;

}

//===========================================================================




int InitGpio(void)

{

	

	//sem_init(&semGpio,0,1);


	//sem_init(&readGpio,0,1);
	
	//sem_init(&writeGpio,0,1);

	/* Drv 오픈 */

	GpioFd = OpenGpio(DRV_GPIO);


	

	/*입력  설정*/

	SetDirectionPortPin(5,5   , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,6   , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,7   , GPIO_DIR_INPUT);

	SetDirectionPortPin(4,28  , GPIO_DIR_INPUT);

	SetDirectionPortPin(4,29  , GPIO_DIR_INPUT);

	SetDirectionPortPin(4,30  , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,9   , GPIO_DIR_INPUT);

	SetDirectionPortPin(3,2	  , GPIO_DIR_INPUT);

	

	SetDirectionPortPin(5,14  , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,15  , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,13  , GPIO_DIR_INPUT);

	SetDirectionPortPin(5,0   , GPIO_DIR_INPUT);

	SetDirectionPortPin(2,15  , GPIO_DIR_INPUT);

	SetDirectionPortPin(6,16  , GPIO_DIR_INPUT);


	SetDirectionPortPin(1,9   , GPIO_DIR_INPUT);

	SetDirectionPortPin(2,10  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,19  , GPIO_DIR_INPUT);


	SetDirectionPortPin(6,15  , GPIO_DIR_INPUT);

	SetDirectionPortPin(3,14  , GPIO_DIR_INPUT);



	SetDirectionPortPin(3,9	  , GPIO_DIR_INPUT);


	SetDirectionPortPin(3,15  , GPIO_DIR_INPUT);

	SetDirectionPortPin(2,27  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,25  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,27  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,28  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,29  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,30  , GPIO_DIR_INPUT);

	SetDirectionPortPin(3,10  , GPIO_DIR_INPUT);

	SetDirectionPortPin(1,18  , GPIO_DIR_INPUT);

	

	SetDirectionPortPin(5,8   , GPIO_DIR_INPUT);

	SetDirectionPortPin(4,31  , GPIO_DIR_INPUT);

	

	/*출력핀 설정*/

	SetDirectionPortPin(4,25   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,26   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,27   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,8    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,20   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,21   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,28   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,22   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(5,10   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(5,11   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(5,12   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(2,9    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(7,12   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,3    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,29   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(1,1    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(1,6    , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(3,11   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,20   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(3,19   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(2,19   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(3,4    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(2,9    , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(1,17   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,13   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,12   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(1,24   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(4,16   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,18   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,19   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(4,17   , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(2,14   , GPIO_DIR_OUTPUT);


	SetDirectionPortPin(3,5    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,6    , GPIO_DIR_OUTPUT);

	SetDirectionPortPin(3,7    , GPIO_DIR_OUTPUT);	

	SetDirectionPortPin(3,8    , GPIO_DIR_OUTPUT);


	return 1;

}


int CloseGpio(void)

{

	int ret = 0;

	

	if( GpioFd <= 0 )

	{

		printf("Gpio Was Not Opened");

	}


	if( (ret = close(fdGpio)) < 0 )

	{

		printf("[Err] Gpio Driver Close Fail");

		perror("message");

		exit(1);

	}

	//sem_destroy(&semGpio);

	//sem_destroy(&readGpio);

	//sem_destroy(&writeGpio);


	printf("Gpio Driver Close OK\r\n");


	return 1;

}


/*Input*/

char ReadDigitalInput0(void)//5-5

{

	return ReadGpio(GPIO_PORT5,GPIO_PIN5);

}

char ReadDigitalInput1(void)//5-6

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN6);

}

char ReadDigitalInput2(void)//5-7

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN7);

}

char ReadDigitalInput3(void)//4-28

{

	return ReadGpio(GPIO_PORT4, GPIO_PIN28);

}

char ReadDigitalInput4(void)//4-29  //

{

	return ReadGpio(GPIO_PORT4, GPIO_PIN29);

}

char ReadDigitalInput5(void)//4-30

{

	return ReadGpio(GPIO_PORT4, GPIO_PIN30);

}

char ReadDigitalInput6(void)//5-9 //

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN9);

}

char ReadDigitalInput7(void)//3-2 //

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN2);

}


char ReadMscInterrupt(void)//5-14

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN14);

}

char ReadFdcInterrupt(void)//5-15

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN15);

}

char ReadTrfInterrupt(void)//5-13

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN13);

}

char ReadFrontKeyInerrupt(void)//5-00

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN0);

}

char ReadEthInterrupt(void)//2-15

{

	return ReadGpio(GPIO_PORT2, GPIO_PIN15);

}

char ReadTouchInterrupt(void)//6-16

{

	return ReadGpio(GPIO_PORT6, GPIO_PIN16);

}


char ReadRealKeyInput(void)//1-9

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN9);

}

char ReadTestKeyInput(void)//2-10

{

	return ReadGpio(GPIO_PORT2, GPIO_PIN10);

}

char ReadCpldComInput(void)//1-19

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN19);

}


char ReadMcuId1(void)//3-14

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN14);

}

char ReadMcuId0(void)//3-15

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN15);

}


char ReadDspState(void)//3-9

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN9);

}


char ReadDspAudioOutDetect(void)//3-15

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN15);

}

char ReadDspAudioInDetect(void)//2-27

{

	return ReadGpio(GPIO_PORT2, GPIO_PIN27);

}

char ReadChargerResetFeedDetect(void)//1-25

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN25);

}

char ReadAcCutOffFeedDetect(void)//1-27

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN27);

}

char ReadStandBy2FeedDetect(void)//1-28

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN28);

}

char ReadStandBy1FeedDetect(void)//1-29

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN29);

}

char ReadAmpResetFeedDetect(void)//1-30

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN30);

}

char ReadDspBootFinishDetect(void)//3-10

{

	return ReadGpio(GPIO_PORT3, GPIO_PIN10);

}

char ReadAmpMuteFeedDetect(void)//1-18

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN18);

}


char ReadCutSwDetect(void)// 4-31

{

	return ReadGpio(GPIO_PORT4, GPIO_PIN31);

}

char ReadMicPttDetect(void)//5-8

{

	return ReadGpio(GPIO_PORT5, GPIO_PIN8);

}

char ReadCpldIn(void)//1-19

{

	return ReadGpio(GPIO_PORT1, GPIO_PIN19);

}

/*Output*/

int ControlDigitalOutput0(unsigned char val)//4-25

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN25, val);

}

int ControlDigitalOutput1(unsigned char val)//4-26

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN26, val);

}

int ControlDigitalOutput2(unsigned char val)//4-27

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN27, val);

}

int ControlDigitalOutput3(unsigned char val)//4-08

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN8, val);

}

int ControlDigitalOutput4(unsigned char val)//3-20

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN20, val);

}

int ControlDigitalOutput5(unsigned char val)//3-21

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN21, val);

}

int ControlDigitalOutput6(unsigned char val)//3-28

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN28, val);

}

int ControlDigitalOutput7(unsigned char val)//3-22

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN22, val);

}


int ControlTrfReset(unsigned char val)//5-10

{

	return WriteGpio(GPIO_PORT5, GPIO_PIN10, val);

}

int ControlMscReset(unsigned char val)//5-11

{

	return WriteGpio(GPIO_PORT5, GPIO_PIN11, val);

}

int ControlFdcReset(unsigned char val)//5-12

{

	return WriteGpio(GPIO_PORT5, GPIO_PIN12, val);

}

int ControlEthReset(unsigned char val)//1-17 -> 2-9

{

	return WriteGpio(GPIO_PORT2, GPIO_PIN9, val);

}

int ControlChargerReset(unsigned char val)//7-12

{

	return WriteGpio(GPIO_PORT7, GPIO_PIN12, val);

}

int ControlTouchControllerReset(unsigned char val)//3-3/

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN3, val);

}

int ControlAmpReset(unsigned char val)//3-29

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN29, val);

}

int ControlWdtStrobe(unsigned char val)//1-1

{

	return WriteGpio(GPIO_PORT1, GPIO_PIN1, val);

}

int ControlWdtOsSelect(unsigned char val)//1-6

{

	return WriteGpio(GPIO_PORT1, GPIO_PIN6, val);

}

int ControlLcdPower(unsigned char val)//3-11

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN11, val);

}

int ControlLcdBacklightEn(unsigned char val)//4-20

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN20, val);

}


int ControlChargerStandBy1(unsigned char val)//3-19

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN19, val);

}

int ControlChargerStandBy2(unsigned char val)//3-16

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN16, val);

}


int ControlSpdifBufferEn(unsigned char val)//3-4

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN4, val);

}

int ControlFrontLedBufferEn(unsigned char val)//7-11

{

	return WriteGpio(GPIO_PORT7, GPIO_PIN11, val);

}


int ControlBuzzer(unsigned char val)//1-17

{

	return WriteGpio(GPIO_PORT1, GPIO_PIN17, val);

}

int ControlAmpMute(unsigned char val)//3-13

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN13, val);

}

int ControlAcCutOff(unsigned char val)//3-12

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN12, val);

}

int ControlCpldOut(unsigned char val)//1-24

{

	return WriteGpio(GPIO_PORT1, GPIO_PIN24, val);

}


int ControlTxLed(unsigned char val)//4-16

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN16, val);

}

int ControlRxLed(unsigned char val)//4-18

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN18, val);

}

int ControlSuLed(unsigned char val)//4-19

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN19, val);

}

int ControlMaLed(unsigned char val)//4-17

{

	return WriteGpio(GPIO_PORT4, GPIO_PIN17, val);

}

int ControlChkLed(unsigned char val)//2-14

{

	return WriteGpio(GPIO_PORT2, GPIO_PIN14, val);

}


int ControlRelay0(unsigned char val)//3-5

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN15, val);

}

int ControlRelay1(unsigned char val)//3-6

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN6, val);

}

int ControlRelay2(unsigned char val)//3-7

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN7, val);

}

int ControlRelay3(unsigned char val)//3-8

{

	return WriteGpio(GPIO_PORT3, GPIO_PIN8, val);

}


//====================================================================================== //


static char SetPinConfigIic(unsigned char port, unsigned char pin)

{

	andGpioCtrlData_t control;


	//sem_wait(&writeGpio);


	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );


	control.gpioPort = port;

	control.gpioPin = pin;


	if( ioctl(fdGpio,SET_PIN_FUNCTION,&control) < 0 )

	{

		perror("ioctl()");

		//sem_post(&writeGpio);

		return -1;

	}


	//sem_post(&writeGpio);


	return 1;

}


static char SetPinConfigGpio(unsigned char port, unsigned char pin)

{

	andGpioCtrlData_t control;


	//sem_wait(&writeGpio);


	memset( &control, 0x00, sizeof(andGpioCtrlData_t) );


	control.gpioPort = port;

	control.gpioPin = pin;


	if( ioctl(fdGpio,SET_PIN_GPIO,&control) < 0 )

	{

		perror("ioctl()");

		//sem_post(&writeGpio);

		return -1;

	}


	//sem_post(&writeGpio);


	return 1;

}


int FunctionIicClkReset(const char type)

{

	unsigned char ctrlPort = 0;

	unsigned char ctrlPin = 0;

	unsigned int loop = 0;

	unsigned char ctrlData = 0;


	switch( type )

	{

		case CTRLIIC_CH1 :

			ctrlPort = GPIO_PORT5;

			ctrlPin = GPIO_PIN27;

			break;

		case CTRLIIC_CH2 :

			ctrlPort = GPIO_PORT4;

			ctrlPin = GPIO_PIN12;

			break;

		case CTRLIIC_CH3 :

			ctrlPort = GPIO_PORT3;

			ctrlPin = GPIO_PIN17;

			break;

		case CTRLIIC_CH4 :

			ctrlPort = GPIO_PORT1;

			ctrlPin = GPIO_PIN7;

			break;

		default :

			return -1;

	}


	if( SetPinConfigGpio(ctrlPort,ctrlPin) < 0 )

	{

		dlp("## control gpio pin config : change iic to gpio fail\r\n");

		return -1;

	}


	dlp("[START] IIC CLK Control used by gpio\r\n");

	for( loop = 0 ; loop < 9 ; loop++ )

	{

		ctrlData = GPIO_LOW;

		if( WriteGpio(ctrlPort,ctrlPin,ctrlData) < 0 )

		{

			dlp("gpio : write fail\r\n");

			break;

		}


		usleep(1);


		ctrlData = GPIO_HIGH;

		if( WriteGpio(ctrlPort,ctrlPin,ctrlData) < 0 )

		{

			dlp("gpio : write fail\r\n");

			break;

		}


		usleep(1);

	}

	dlp("[END] IIC CLK Control used by gpio\r\n");


	if( SetPinConfigIic(ctrlPort,ctrlPin) < 0 )

	{

		dlp("control gpio config : change gpio to iic fail\r\n");

		return -1;

	}


	return 1;

}


//============Card



/*DEVICE GPIO*/


#if 0

void InitGpio(void)

{

	sem_init(&semGpio,0,1);

	sem_init(&readGpio,0,1);

	sem_init(&writeGpio,0,1);


	/* Drv 오픈 */

	if(GpioFd <= 0)

	{

		GpioFd = OpenGpio(DRV_GPIO);

	}

}


void DeinitGpio(void)

{

	int ret = 0;

	

	if( GpioFd <= 0 )

	{

		printf("Gpio Was Not Opened");

	}


	if( (ret = close(fdGpio)) < 0 )

	{

		printf("[Err] Gpio Driver Close Fail");

		perror("message");

		exit(1);

	}

	sem_destroy(&semGpio);

	sem_destroy(&readGpio);

	sem_destroy(&writeGpio);


	printf("Gpio Driver Close OK\r\n");

#endif
}


#endif






