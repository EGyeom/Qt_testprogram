
//#pragma once

#ifndef __API_DEFS_H__

#define __API_DEFS_H__


#include <stdint.h>


// for System Log

#define CMDSIZE		  250


// GPIO Value

#define GPIO_LOW	  0

#define GPIO_HIGH	  1


// S/W Flag

#define FLAG_OFF	  0

#define FLAG_ON		  1


// Chg Status

#define CHG36V_OFF		  0

#define CHG36V_ON_BROAD	  1

#define CHG36V_ON_MCU	  2

#define CHG36V_ON_EAU	  3


// Status Flag

#define STATUS_OK	  0

#define STATUS_FAULT  1

#define STATUS_ACTIVE 2

#define STATUS_NONE	  3


// amp power

#define STA_AMP_POWER_ON	0

#define STA_AMP_POWER_OFF	2


// Trespass

#define TRESPASS_LOGOUT	'0'

#define TRESPASS_LOGIN	'1'


// Use Info

#define INFO_UNUSE	  0

#define INFO_USE	  1


// Program 관리

#define PROGRAM_KIND_MAIN	  0x00

#define PROGRAM_KIND_UI		  0x01

#define PROGRAM_KIND_STOMSG	  0x02


#define PROGRAM_PATH_MAIN "/userfile/"

#define PROGRAM_PATH_UI	  "/userfile/IWT_UI/"


#define FILENAME_SKELETON_MAIN	"iwt_app_"

#define FILENAME_SKELETON_UI	"IWT_UI_"

#define FILENAME_SKELETON_STOMSG  "iwt_wave"


#define MOUNT_USB_DIR	"/mnt/"


// Charger Info

#define CHG_NUM	  2

#define CHG_VALUE_STACK_CNT	  15


#define CHG_NUM1	0

#define CHG_NUM2	1


// Tc Sub Command

#define SC_SET		0

#define SC_REQUEST	1


// For Error Message

#define ERR_BUFSIZE	256


#define PACK_DLE	0x10

#define PACK_SOH	0x01

#define PACK_ESC	0x1B

#define PACK_STX	0x02

#define PACK_ETX	0x03

#define PACK_EOT	0x04

#define PACK_CR		0x0D

#define PACK_LF		0x0A

#define PACK_PLUS	0x2B


#define PACK_BLE_HEADER	  0xAA

#define PACK_BLE_TRAILER  0x55


#define PACK_ANDBLE_HEADER1	0xAA

#define PACK_ANDBLE_HEADER2	0xBE


#define PACK_SYNC	0x96	// 0x69


#define FLAG_ON	 1

#define FLAG_OFF 0


#define GPIO_LOW 0

#define GPIO_HIGH 1


#define MUTE_ON  0

#define MUTE_OFF 1



#define PORT0 0

#define PORT1 1

#define PORT2 2

#define PORT3 3

#define PORT4 4

#define PORT5 5

#define PORT6 6

#define PORT7 7

#define PORT8 8

#define PORT9 9


#define PIN0 0 

#define PIN1 1

#define PIN2 2

#define PIN3 3

#define PIN4 4

#define PIN5 5

#define PIN6 6

#define PIN7 7


#define INPUT  1 

#define OUTPUT 0


#define HIGH 1

#define LOW 0


// TCP Tx Data Flag

#define TCP_PORT_KB		5000	// 경보대 PORT

#define TCP_PORT_JJ		5002	// 주제어 PORT

#define TCP_PORT_WE		5015	// 기상 서버 PORT

#define TCP_PORT_UI		9000	// UI PORT


#define UDP_PORT_KB		5000	// 경보대 PORT

#define UDP_PORT_JJ		5002	// 주제어 PORT


// Net-Tc-Broad Struct Src Device

#define DEV_SRC_UNKNOWN		0		// Unknown

#define DEV_SRC_LINE_TCP_KB	1		// TCP 경보대

#define DEV_SRC_LINE_UDP_KB	2		// UDP 경보대

#define DEV_SRC_LINE_TCP_JJ	3		// TCP 주제어

#define DEV_SRC_LINE_UDP_JJ	4		// UDP 주제어

#define DEV_SRC_SATELLITE	5		// 위성

#define DEV_SRC_LINE_TCP_WE	6		// 기상 서버

#define DEV_SRC_UI			7		// UI Program

#define DEV_SRC_RCU			8		// RCU

#define DEV_SRC_RCC			9		// RCC

#define DEV_SRC_EUPMYUN		10		// 읍면동

#define DEV_SRC_FIU			11		// FIU

#define DEV_SRC_EAU			12		// EAU

#define DEV_SRC_MIC			13		// 단말 MIC

#define DEV_SRC_TERM		14		// 단말-->자동해제

#define DEV_SRC_UI_USB		15		// 저장메시지 발령에서만 사용한다.


#define TCP_RET_TX_KB	0x01	// 전송한 경보대로만 응답(TCP)

#define TCP_RET_TX_JJ	0x02	// 전송한 주제어로만 응답(TCP)

#define TCP_RET_TX_WE	0x03	// 전송한 기상 서버로만 응답(TCP)

#define TCP_ALL_TX_KB	0x04	// 연결된 모든 경보대로 응답(TCP)

#define TCP_ALL_TX_JJ	0x05	// 연결된 모든 주제어로 응답(TCP)

#define TCP_ALL_TX_WE	0x06	// 연결된 모든 기상서버로 응답(TCP)

#define UDP_RET_TX_KB	0x07	// 전송한 경보대로만 응답(UDP)

#define UDP_RET_TX_JJ	0x08	// 전송한 주제어로만 응답(UDP)

#define UDP_RET_TX_KISA	0x09	// 전송한 주제어로만 응답(UDP->인증키 응답 전옹)

#define TCP_RET_TX_UI	0x0C	// UI로 응답


#define BROADWAV_ALERT			1

#define BROADWAV_AIRRAID		2

#define BROADWAV_DISASTER_RISK	3

#define BROADWAV_CHIMEBELL		4

#define BROADWAV_STO_MSG		5

#define TESTWAV_SILENT		    6

#define TESTWAV_BIRD			7

#define TESTWAV_CHICKEN			8

#define BROADWAV_USB_STO_MSG	9


#define IWT_APP_KIND_MAIN		0

#define IWT_APP_KIND_TEST		1


#define FM_NUM1	  0

#define FM_NUM2	  1

#define FM_ALLOFF 3


#define SI4730_FM_RECEIVER	  0

#define SI4730_AM_RECEIVER	  1


#define SI4730_DIGITAL_AUDIO  0

#define SI4730_ANALOG_AUDIO	  1


#define START_UI_RUN	"/userfile/IWT_UI/run.sh &"



#endif


