#ifndef _API_GPIO_H_

#define _API_GPIO_H_


#define CTRLIIC_CH1	  1

#define CTRLIIC_CH2	  2

#define CTRLIIC_CH3	  3

#define CTRLIIC_CH4	  4


// GPIO PORT & PIN Defines ----------------------------------------------------------------------------- //

#define GPIO_PORT1	1

#define GPIO_PORT2	2

#define GPIO_PORT3	3

#define GPIO_PORT4	4

#define GPIO_PORT5	5

#define GPIO_PORT6	6

#define GPIO_PORT7	7


#define GPIO_PIN0	0

#define GPIO_PIN1	1

#define GPIO_PIN2	2

#define GPIO_PIN3	3

#define GPIO_PIN4	4

#define GPIO_PIN5	5

#define GPIO_PIN6	6

#define GPIO_PIN7	7

#define GPIO_PIN8	8

#define GPIO_PIN9	9

#define GPIO_PIN10	10

#define GPIO_PIN11	11

#define GPIO_PIN12	12

#define GPIO_PIN13	13

#define GPIO_PIN14	14

#define GPIO_PIN15	15

#define GPIO_PIN16	16

#define GPIO_PIN17	17

#define GPIO_PIN18	18

#define GPIO_PIN19	19

#define GPIO_PIN20	20

#define GPIO_PIN21	21

#define GPIO_PIN22	22

#define GPIO_PIN23	23

#define GPIO_PIN24	24

#define GPIO_PIN25	25

#define GPIO_PIN26	26

#define GPIO_PIN27	27

#define GPIO_PIN28	28

#define GPIO_PIN29	29

#define GPIO_PIN30	30

#define GPIO_PIN31	31


// ----------------------------------------------------------------------------------------------------- //

	#define DRV_GPIO  "/dev/gio"

	// GPIO 드라이버 옵션 - /dev/gpio0

	#define GPIO_DIR_SET		_IOW('g',0x01,int)	// gpio pin direction setting output

	#define GPIO_OUTPUT_WRITE	_IOW('g',0x02,int)	// gpio pin output high

	#define GPIO_INPUT_READ		_IOW('g',0x03,int)	// gpio pin input read value (1:high / 0:low)

	#define GPIO_FREE			_IOW('g',0x04,int)	// gpio pin export free


	#define SET_PIN_GPIO		_IOW('g',0x05,int)

	#define SET_PIN_FUNCTION	_IOW('g',0x06,int)

#endif

//---------------------------------------------------------------------------------- //




#define GPIO_DIR_OUTPUT 0

#define GPIO_DIR_INPUT	1


#define GPIO_OUT_LOW	0

#define GPIO_OUT_HIGH	1


// ====================================================================================//

/*MX6 GPIO_NUM */

#define IMX_GPIO_NR(port, index)   ((((port)-1)*32)+((index)&31)) 



typedef class andGpioCtrlData {
public:
	unsigned int gpioPort;

	unsigned int gpioPin;

	unsigned int data;

}__attribute__((packed))andGpioCtrlData_t;

//__attribute__((packed))

typedef class _gpio

{
public:
	int fd; 

	int gpio;

	int flags;

	int defult_val;

}gpio_t;




int SetDirectionPortPin(unsigned char port, unsigned char pin, unsigned char direct);

int WriteGpio(unsigned int port, unsigned int pin, unsigned char data);

char ReadGpio(unsigned int port, unsigned int pin);




















//============================JIG


/*Init*/


int InitGpio(void);

int CloseGpio(void);

/*Input*/ 


char ReadMcuId1(void);//6-15

char ReadMcuId0(void);//3-14

int ControlTxLed(unsigned char val);//4-16

int ControlRxLed(unsigned char val);//4-18

int ControlSuLed(unsigned char val);//4-19

int ControlMaLed(unsigned char val);//4-17

int ControlChkLed(unsigned char val);//Jig 2-14  Card 4-20

char ReadDspAudioOutDetect(void);//3-15

char ReadDspAudioInDetect(void);//2-27

char ReadDspBootFinishDetect(void);//3-10


char ReadDspState(void);//3-9

char ReadDigitalInput0(void);//5-5

char ReadDigitalInput1(void);//5-6

char ReadDigitalInput2(void);//5-7

char ReadDigitalInput3(void);//4-28

char ReadDigitalInput4(void);//4-29

char ReadDigitalInput5(void);//4-30

char ReadDigitalInput6(void);//5-9

char ReadDigitalInput7(void);//3-2


char ReadMscInterrupt(void);//5-14

char ReadFdcInterrupt(void);//5-15

char ReadTrfInterrupt(void);//5-13

char ReadFrontKeyInerrupt(void);//5-00

char ReadEthInterrupt(void);//2-15

char ReadTouchInterrupt(void);//6-16


char ReadRealKeyInput(void);//1-9

char ReadTestKeyInput(void);//2-10

char ReadCpldComInput(void);//1-19




char ReadChargerResetFeedDetect(void);//1-25

char ReadAcCutOffFeedDetect(void);//1-27

char ReadStandBy2FeedDetect(void);//1-28

char ReadStandBy1FeedDetect(void);//1-29

char ReadAmpResetFeedDetect(void);//1-30

char ReadAmpMuteFeedDetect(void);//1-18

char ReadCutSwDetect(void);//5-8

char ReadMicPttDetect(void);//4-31


/*Output*/

int ControlDigitalOutput0(unsigned char val);//4-25

int ControlDigitalOutput1(unsigned char val);//4-26

int ControlDigitalOutput2(unsigned char val);//4-27

int ControlDigitalOutput3(unsigned char val);//4-08

int ControlDigitalOutput4(unsigned char val);//3-20

int ControlDigitalOutput5(unsigned char val);//3-21

int ControlDigitalOutput6(unsigned char val);//3-28

int ControlDigitalOutput7(unsigned char val);//3-22


int ControlTrfReset(unsigned char val);//5-10

int ControlMscReset(unsigned char val);//5-11

int ControlFdcReset(unsigned char val);//5-12

int ControlEthReset(unsigned char val);//2-9

int ControlChargerReset(unsigned char val);//7-12

int ControlTouchControllerReset(unsigned char val);//3-3

int ControlAmpReset(unsigned char val);//3-29


int ControlWdtStrobe(unsigned char val); //1-1

int ControlWdtOsSelect(unsigned char val);//1-6


int ControlLcdPower(unsigned char val);//3-11

int ControlLcdBacklightEn(unsigned char val); //4-20


int ControlChargerStandBy1(unsigned char val);//3-19

int ControlChargerStandBy2(unsigned char val);//2-19


int ControlSpdifBufferEn(unsigned char val);//3-4

int ControlFrontLedBufferEn(unsigned char val);//7-11


int ControlBuzzer(unsigned char val); //1-17

int ControlAmpMute(unsigned char val);//3-13

int ControlAcCutOff(unsigned char val);//3-12

int ControlCpldOut(unsigned char val);//1-24


int ControlRelay0(unsigned char val);//3-5

int ControlRelay1(unsigned char val);//3-6

int ControlRelay2(unsigned char val);//3-7

int ControlRelay3(unsigned char val);//3-8


int FunctionIicClkReset(const char type);





//#endif /* HEADER_FILE_ID */
