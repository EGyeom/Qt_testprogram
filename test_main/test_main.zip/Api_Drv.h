//#pragma once
// compiler(preprocessor) 가 해당 파일을 한번만 읽도록 하는 명령 
// 몇몇 preprocessor 에서는 이해할 수 없을 수도 있다고 명시되어 있음.
// #ifndef Style도 C preprocessor에서 기억하는 기능이 있어 한번만 읽도록 하는 기능이 가능하다.

#ifndef __API_DRV_H__
#define __API_DRV_H__

#define DRV_IIC_CH0		"/dev/i2c-0"
#define DRV_IIC_CH1		"/dev/i2c-1"
#define DRV_IIC_CH2		"/dev/i2c-2"
#define DRV_IIC_CH3		"/dev/i2c-3"
#define DRV_IIC_CH4		"/dev/i2c-4"
#define DRV_IIC_CH5		"/dev/i2c-5"
#define DRV_IIC_CH6		"/dev/i2c-6"
#define DRV_IIC_CH7		"/dev/i2c-7"
#define DRV_IIC_CH8		"/dev/i2c-8"
#define DRV_IIC_CH9		"/dev/i2c-9"
#define DRV_IIC_CH10	"/dev/i2c-10"
#define DRV_IIC_CH11	"/dev/i2c-11"

#define DRV_CPLD "/dev/cpld_drv"

#define DRV_INT_UART	"/dev/ttymxc"
#define DRV_EXT_UART	"/dev/ttyS"

#define DRV_COM1 "/dev/ttymxc0"
#define DRV_COM2 "/dev/ttymxc1"
#define DRV_COM3 "/dev/ttymxc2"
#define DRV_COM4 "/dev/ttyS0"
#define DRV_COM5 "/dev/ttyS1"
#define DRV_COM6 "/dev/ttyS2"
#define DRV_COM7 "/dev/ttyS3"
#define DRV_COM8 "/dev/ttyS4"
#define DRV_COM9 "/dev/ttyS5"
#define DRV_COM10 "/dev/ttyS6"
#define DRV_COM11 "/dev/ttyS7"
#define DRV_COM12 "/dev/ttyS8"
#define DRV_COM13 "/dev/ttyS9"
#define DRV_COM14 "/dev/ttyS10"
#define DRV_COM15 "/dev/ttyS11"



#define CFG_BAUD_1200		0
#define CFG_BAUD_2400		1
#define CFG_BAUD_4800		2
#define CFG_BAUD_9600		3
#define CFG_BAUD_19200		4
#define CFG_BAUD_38400		5
#define CFG_BAUD_57600		6
#define CFG_BAUD_115200		7
#define CFG_BAUD_230400		8
#define CFG_BAUD_460800		9
#define CFG_BAUD_921600		10

#endif

